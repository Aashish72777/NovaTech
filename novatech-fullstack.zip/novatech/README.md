# NovaTech Solutions — Full Stack Web Project

A complete full-stack website built with **HTML/CSS/JS** frontend and **Node.js + Express** backend, featuring authentication, JWT, and a JSON database.

---

## 🗂 Project Structure

```
novatech/
├── backend/                  ← Express.js API server
│   ├── config/
│   │   └── db.js             ← LowDB JSON database config
│   ├── controllers/
│   │   ├── authController.js ← Register, Login, Profile logic
│   │   └── contactController.js ← Contact form logic
│   ├── middleware/
│   │   └── auth.js           ← JWT authentication middleware
│   ├── routes/
│   │   ├── authRoutes.js     ← Auth API routes
│   │   └── contactRoutes.js  ← Contact API routes
│   ├── data/
│   │   └── db.json           ← JSON file database (auto-created)
│   ├── .env                  ← Environment variables
│   └── server.js             ← Main server entry point
│
└── frontend/
    └── index.html            ← Complete SPA frontend (5 pages)
```

---

## 🛠 Tech Stack

| Layer      | Technology                          |
|------------|-------------------------------------|
| Frontend   | HTML5, CSS3, Vanilla JavaScript     |
| Backend    | Node.js, Express.js                 |
| Auth       | JWT (jsonwebtoken), bcryptjs        |
| Database   | LowDB v1 (JSON file-based DB)       |
| Security   | bcrypt password hashing, JWT tokens |

---

## 🚀 Setup & Run

### Prerequisites
- Node.js v16+ installed
- npm installed

### 1. Install backend dependencies
```bash
cd backend
npm install
```

### 2. Configure environment
The `.env` file is already set up with:
```
PORT=5000
JWT_SECRET=novatech_super_secret_jwt_key_2025
JWT_EXPIRES_IN=7d
```

### 3. Start the server
```bash
cd backend
node server.js
```
Server starts at: **http://localhost:5000**

### 4. Open the website
Navigate to **http://localhost:5000** in your browser.

---

## 📡 API Endpoints

### Auth Routes (`/api/auth`)

| Method | Endpoint         | Auth Required | Description              |
|--------|-----------------|--------------|--------------------------|
| POST   | /register        | No           | Create a new account     |
| POST   | /login           | No           | Login and get JWT token  |
| GET    | /profile         | Yes (JWT)    | Get current user profile |
| GET    | /users           | Yes (admin)  | Get all users            |

### Contact Routes (`/api/contact`)

| Method | Endpoint   | Auth Required | Description              |
|--------|-----------|--------------|--------------------------|
| POST   | /          | No           | Submit contact form      |
| GET    | /          | Yes (JWT)    | Get all submissions      |

### Other

| Method | Endpoint     | Description         |
|--------|-------------|---------------------|
| GET    | /api/health  | Server health check |

---

## 📋 Request & Response Examples

### Register
```
POST /api/auth/register
Content-Type: application/json

{
  "name": "Arjun Sharma",
  "email": "arjun@email.com",
  "password": "securepass123"
}

Response:
{
  "success": true,
  "message": "Account created successfully!",
  "token": "eyJhbGci...",
  "user": { "id": "...", "name": "Arjun Sharma", "email": "...", "role": "user" }
}
```

### Login
```
POST /api/auth/login
Content-Type: application/json

{
  "email": "arjun@email.com",
  "password": "securepass123"
}
```

### Protected Route
```
GET /api/auth/profile
Authorization: Bearer <your_jwt_token>
```

---

## 🌐 Frontend Pages

| Page       | Route (SPA)   | Description                          |
|------------|--------------|--------------------------------------|
| Home       | #home        | Hero, Features, Stats, Testimonials  |
| About      | #about       | Team, Timeline, Company Info         |
| Services   | #services    | All 6 service offerings              |
| Pricing    | #pricing     | 3-tier plans + FAQ accordion         |
| Contact    | #contact     | Contact form (connected to API)      |
| Dashboard  | #dashboard   | Protected — JWT auth required        |

---

## 🔒 Security Features

- Passwords hashed with **bcrypt** (salt rounds: 10)
- **JWT tokens** expire in 7 days
- Protected routes require valid Bearer token
- Duplicate email prevention on registration
- Input validation on all API endpoints
- CORS configured for local development

---

## 📝 Notes

- Database is stored in `backend/data/db.json` (auto-created on first run)
- No SQL setup required — uses LowDB (JSON file database)
- Frontend fetches all data from `http://localhost:5000/api`
- JWT token stored in `localStorage` on the client
- Dashboard page is only accessible after login

---

## 👨‍💻 Author

NovaTech Solutions — Advanced Full Stack Web Project  
Built with Node.js + Express + HTML/CSS/JS
