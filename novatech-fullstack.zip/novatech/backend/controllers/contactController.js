const { v4: uuidv4 } = require('uuid');
const db = require('../config/db');

// ── SUBMIT CONTACT FORM ───────────────────────────────
exports.submitContact = (req, res) => {
  try {
    const { firstName, lastName, email, subject, message } = req.body;

    if (!firstName || !email || !message) {
      return res.status(400).json({ success: false, message: 'First name, email, and message are required.' });
    }

    const entry = {
      id: uuidv4(),
      firstName: firstName.trim(),
      lastName: (lastName || '').trim(),
      email: email.toLowerCase().trim(),
      subject: subject || 'General',
      message: message.trim(),
      status: 'new',
      createdAt: new Date().toISOString()
    };

    db.get('contacts').push(entry).write();

    res.status(201).json({
      success: true,
      message: 'Your message has been received! We\'ll reply within 24 hours.',
      id: entry.id
    });
  } catch (err) {
    console.error('Contact error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── GET ALL CONTACTS (protected) ─────────────────────
exports.getAllContacts = (req, res) => {
  const contacts = db.get('contacts').value();
  res.json({ success: true, count: contacts.length, contacts });
};
