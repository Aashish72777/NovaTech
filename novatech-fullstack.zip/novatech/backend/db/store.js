// In-memory store — simulates a real database
// In production, replace with MongoDB / PostgreSQL / MySQL

const db = {
  users: [],
  contacts: [],
  sessions: [],
  nextId: 1
};

// Seed an admin user
const bcrypt = require('bcryptjs');
const salt = bcrypt.genSaltSync(10);
db.users.push({
  id: db.nextId++,
  name: 'Admin User',
  email: 'admin@novatech.in',
  password: bcrypt.hashSync('Admin@123', salt),
  role: 'admin',
  createdAt: new Date().toISOString(),
  avatar: 'AU'
});

module.exports = db;
