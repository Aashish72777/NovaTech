const express = require('express');
const router = express.Router();
const db = require('../db/store');
const authMiddleware = require('../middleware/auth');

// GET /api/users — all users (admin only)
router.get('/', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin access required.' });
  }
  const users = db.users.map(({ password, ...u }) => u);
  res.json({ success: true, total: users.length, users });
});

// GET /api/users/:id — get single user
router.get('/:id', authMiddleware, (req, res) => {
  const id = parseInt(req.params.id);
  if (req.user.id !== id && req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Access denied.' });
  }
  const user = db.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
  const { password, ...safeUser } = user;
  res.json({ success: true, user: safeUser });
});

module.exports = router;
