const express = require('express');
const router = express.Router();
const db = require('../db/store');
const authMiddleware = require('../middleware/auth');

// POST /api/contact — submit contact form (public)
router.post('/', (req, res) => {
  const { firstName, lastName, email, subject, message } = req.body;
  if (!firstName || !email || !message) {
    return res.status(400).json({ success: false, message: 'First name, email, and message are required.' });
  }
  const entry = {
    id: db.nextId++,
    firstName, lastName, email, subject, message,
    status: 'new',
    createdAt: new Date().toISOString()
  };
  db.contacts.push(entry);
  console.log('New contact submission:', entry);
  res.status(201).json({ success: true, message: 'Message received! We\'ll be in touch within 24 hours.' });
});

// GET /api/contact — list submissions (admin only)
router.get('/', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin access required.' });
  }
  res.json({ success: true, total: db.contacts.length, contacts: db.contacts });
});

module.exports = router;
