const express = require('express');
const router = express.Router();
const contactController = require('../controllers/contactController');
const protect = require('../middleware/auth');

// POST /api/contact
router.post('/', contactController.submitContact);

// GET /api/contact  (protected)
router.get('/', protect, contactController.getAllContacts);

module.exports = router;
