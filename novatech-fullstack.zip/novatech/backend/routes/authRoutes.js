const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const protect = require('../middleware/auth');

// POST /api/auth/register
router.post('/register', authController.register);

// POST /api/auth/login
router.post('/login', authController.login);

// GET /api/auth/profile  (protected)
router.get('/profile', protect, authController.getProfile);

// GET /api/auth/users  (admin only)
router.get('/users', protect, authController.getAllUsers);

module.exports = router;
